# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from siteDemo.models import Publisher, Author, Lu , Rtable , Ecs , Dbinfo

admin.site.register(Publisher)
admin.site.register(Author)
admin.site.register(Lu)
admin.site.register(Rtable)
admin.site.register(Ecs)
admin.site.register(Dbinfo)


# Register your models here.
